# -*- coding: utf-8 -*-
"""
Created on Thu Jun 20 15:26:11 2024

@author: LF
"""
'''本程序用于绘制站点分布图，并将卫星影像当做底图。'''
#无需更换IGBP
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%读入站点信息并统计分类
file_path = 'F:/phd1/V8/01allsite/03trend/lonlat_sen.xlsx'
latlon_df = pd.read_excel(file_path)
proportions_di = latlon_df['di_trend'].value_counts(normalize=True, ascending=False)*100  # 计算每个唯一值的比例
proportions_wue = latlon_df['wue_trend'].value_counts(normalize=True, ascending=False)*100  # 计算每个唯一值的比例
di_percen = pd.DataFrame(index = ['SMDIi','SMDIn','SMDId'], columns=['SPEIi','SPEIn','SPEId'])
wue_percen = pd.DataFrame(index = ['IWUEi','IWUEn','IWUEd'], columns=['TWUEi','TWUEn','TWUEd'])
for ii in range(9):
    try:
        quotient, remainder = divmod(ii, 3)
        di_percen.iloc[quotient, remainder] = proportions_di[ii+1]
        wue_percen.iloc[quotient, remainder] = proportions_wue[ii+1]
    except KeyError as e:
        pass
di_percen.to_excel('F:/phd1/V8/01allsite/03trend/proportions_di.xlsx', index=True, header=True, float_format='%.4f')
wue_percen.to_excel('F:/phd1/V8/01allsite/03trend/proportions_wue.xlsx', index=True, header=True, float_format='%.4f')

#%%以干旱指数为类，统计WUE趋势
wue_stat = pd.DataFrame(index=(4,6,9),columns=list(range(1,10)))
for vv in [4,6,9]:   
    filtered_df = latlon_df[latlon_df['di_trend'] == vv]  # 过滤DataFrame    
    propor = filtered_df['wue_trend'].value_counts(normalize=True)*100   # 计算比例
    propor1 = propor.drop(5)[0:5]
    wue_stat.loc[vv,:] = propor1.T
wue_stat.to_excel('F:/phd1/V8/01allsite/03trend/wue_stat.xlsx', index=True, header=True, float_format='%.4f')
parameters = {'axes.labelsize': 30,
          'axes.titlesize': 25,
          'xtick.labelsize': 30,
          'ytick.labelsize': 30,
          'figure.dpi': 300,    
          'font.family': 'Arial'}
plt.rcParams.update(parameters)
fig, axs = plt.subplots(nrows=1, ncols=3, figsize=(18, 6))  # 创建包含3个子图的大图
zz=0
for i, row in wue_stat.iterrows():    # 绘制每一行的横向柱状图
    row = row.dropna().sort_values(ascending=False)   # 去除NaN值，并按值排序    
    # # 绘制横向棒棒糖图  
    sorted_index = row.index  # 获取排序后的索引和值
    sorted_values = row.values
    
    # 横向棒棒糖图
    axs[zz].hlines(y=range(len(sorted_values)), xmin=0, xmax=sorted_values, color='#3498DB', linewidth=4)  # 画线条
    axs[zz].plot(sorted_values, range(len(sorted_values)), "o", color='#E74C3C', markersize=15)  # 画点
    axs[zz].set_yticks(range(len(sorted_values)))
    axs[zz].set_yticklabels(sorted_index)
    axs[zz].set_xlabel('WUE proportions(%)')
    axs[zz].set_title(f'DI class {i}')    
    axs[zz].invert_yaxis()  # 将Y轴标签设置为从大到小的顺序
    zz+=1
plt.subplots_adjust(wspace=0.4)  # 增加横向间距
plt.show()
fig.savefig("F:/phd1/V8/01allsite/03trend/percentage_wue.jpg",dpi=300, format='jpg', bbox_inches='tight')

#%%绘制空间分布图
parameters = {'axes.labelsize': 55,
          'axes.titlesize': 35,
          'xtick.labelsize': 50,
          'ytick.labelsize': 50,
          'figure.dpi': 300,    
          'font.family': 'Arial'}
plt.rcParams.update(parameters)

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(20, 20), dpi=300, subplot_kw={'projection': ccrs.PlateCarree()})
proj = ccrs.PlateCarree()  #中央经线为东经10度的等经纬投影
extent = [-180, 180, -90, 90]  #西东南北边界
def ax_set(ax):  #设置子图参数
    ax.set_extent(extent)  #设定空间范围
    land_feature = cfeature.NaturalEarthFeature(category='physical',name='land',scale='50m',facecolor='#D3D3D3')   # 设置陆地的颜色        
    ax.add_feature(land_feature, zorder=0)  # 添加自定义的陆地特征到绘图
    #ax.add_feature(cfeature.LAND)   #添加陆地
    ax.add_feature(cfeature.OCEAN)   #添加海洋
    ax.coastlines(resolution = '50m')  #添加海岸线
    #ax.add_feature(cfeature.BORDERS,lw=0.5)
    gl = ax.gridlines(crs=proj, draw_labels=True, linewidth=1.2, color='k', alpha=0.5, linestyle='--')  # 设置网格点属性
    gl.top_labels = False
    gl.right_labels = False
    gl.xlabel_style = {'size': 30}
    gl.ylabel_style = {'size': 30}
    return gl
gl1 = ax_set(ax1)
gl2 = ax_set(ax2)
# 定义颜色映射
di_dict = {
    1: (13,101,189,1),  
    2: (62,142,196,1),  
    3: (161,203,226,1),
    4: (190,216,235,1),  
    5: (246,246,246,1),  
    6: (251,140,108,1),  
    7: (251,111,79,1),  
    8: (235,55,41,1),  
    9: (205,26,29,1)    
}
# 初始化颜色列表
latlon_df['di_colors'] = latlon_df['di_trend'].apply(lambda x: di_dict[x])

# 定义颜色映射
wue_dict = {
    1: (108,85,165,1),  
    2: (128,125,186,1),  
    3: (148,144,195,1),
    4: (177,176,212,1),  
    5: (246,246,246,1),  
    6: (161,217,165,1),  
    7: (116,196,118,1),  
    8: (70,173,95,1),  
    9: (0,98,39,1)    
}
# 初始化颜色列表
latlon_df['wue_colors'] = latlon_df['wue_trend'].apply(lambda x: wue_dict[x])

# 定义形状映射
shape_dict = {
    'EBF': 'D',  # 圆形
    'DBF': 's',  # 方形
    'ENF': '^',  # 三角形
    'GRA': 'o',  # 菱形
    'MIF': 'H',  # 倒三角形
    'SHR': 'P',  # 五边形
    'SAV': '*'  # 星形    
}
# 绘制站点
for rr in range(len(latlon_df)):
    row = latlon_df.iloc[rr,:]
    igbp = row['igbp']        
    di_colors = row['di_colors']
    wue_colors = row['wue_colors']
    di_ncolor = tuple(c / 255.0 for c in di_colors[:3])   #根据字典索引指定颜色
    wue_ncolor = tuple(c / 255.0 for c in wue_colors[:3])
    # 形成新的包含RGBA的元组
    di_ncolor_alpha = (di_ncolor[0], di_ncolor[1], di_ncolor[2], di_colors[3])
    wue_ncolor_alpha = (wue_ncolor[0], wue_ncolor[1], wue_ncolor[2], wue_colors[3])
    sc1 = ax1.scatter(row['lon'], row['lat'], c = di_ncolor_alpha, 
                    s=100, edgecolor='k', marker=shape_dict[igbp], transform=ccrs.PlateCarree())  #绘制散点图
    sc2 = ax2.scatter(row['lon'], row['lat'], c = wue_ncolor_alpha, 
                    s=100, edgecolor='k', marker=shape_dict[igbp], transform=ccrs.PlateCarree())

ax1.set_title('(A) Drought Index Trend', pad = 15)
ax2.set_title('(B) WUEs Trend', pad = 15)
# 创建图例
handles = [mlines.Line2D([], [], color='black', marker=shape, linestyle='None', markersize=20, label=igbp) for igbp, shape in shape_dict.items()]
fig.legend(handles=handles, loc='right', fontsize=30, bbox_to_anchor=(1.0, 0.5), frameon=False)    
plt.show()
#pos2 = ax2.get_position()
# 调整第二个子图的位置
#ax2.set_position([pos2.x0 - 0.05, pos2.y0, pos2.width, pos2.height])  # 将第二个子图左移并缩小宽度
fig.savefig("F:/phd1/V8/01allsite/03trend/latlon_trend.jpg",dpi=300, format='jpg', bbox_inches='tight')
#%%绘制欧洲图
parameters = {'axes.labelsize': 55,
          'axes.titlesize': 35,
          'xtick.labelsize': 50,
          'ytick.labelsize': 50,
          'figure.dpi': 300,    
          'font.family': 'Arial'}
plt.rcParams.update(parameters)

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(20, 20), dpi=300, subplot_kw={'projection': ccrs.PlateCarree()})
proj = ccrs.PlateCarree()  #中央经线为东经10度的等经纬投影
extent = [-10, 30, 35, 70]  #西东南北边界
def ax_set(ax):  #设置子图参数
    ax.set_extent(extent)  #设定空间范围
    land_feature = cfeature.NaturalEarthFeature(category='physical',name='land',scale='50m',facecolor='#D3D3D3')   # 设置陆地的颜色        
    ax.add_feature(land_feature, zorder=0)  # 添加自定义的陆地特征到绘图
    #ax.add_feature(cfeature.LAND)   #添加陆地
    ax.add_feature(cfeature.OCEAN)   #添加海洋
    ax.coastlines(resolution = '50m')  #添加海岸线
    #ax.add_feature(cfeature.BORDERS,lw=0.5)
    gl = ax.gridlines(crs=proj, draw_labels=True, linewidth=1.2, color='k', alpha=0.5, linestyle='--')  # 设置网格点属性
    gl.top_labels = False
    gl.right_labels = False
    gl.bottom_labels = False
    gl.left_labels = False
    return gl
gl1 = ax_set(ax1)
gl2 = ax_set(ax2)
# 定义颜色映射
di_dict = {
    1: (13,101,189,1),  
    2: (62,142,196,1),  
    3: (161,203,226,1),
    4: (190,216,235,1),  
    5: (246,246,246,1),  
    6: (251,140,108,1),  
    7: (251,111,79,1),  
    8: (235,55,41,1),  
    9: (205,26,29,1)    
}
# 初始化颜色列表
latlon_df['di_colors'] = latlon_df['di_trend'].apply(lambda x: di_dict[x])

# 定义颜色映射
wue_dict = {
    1: (108,85,165,1),  
    2: (128,125,186,1),  
    3: (148,144,195,1),
    4: (177,176,212,1),  
    5: (246,246,246,1),  
    6: (161,217,165,1),  
    7: (116,196,118,1),  
    8: (70,173,95,1),  
    9: (0,98,39,1)    
}
# 初始化颜色列表
latlon_df['wue_colors'] = latlon_df['wue_trend'].apply(lambda x: wue_dict[x])

# 定义形状映射
shape_dict = {
    'EBF': 'D',  # 圆形
    'DBF': 's',  # 方形
    'ENF': '^',  # 三角形
    'GRA': 'o',  # 菱形
    'MIF': 'H',  # 倒三角形
    'SHR': 'P',  # 五边形
    'SAV': '*'  # 星形    
}
# 绘制站点
for rr in range(len(latlon_df)):
    row = latlon_df.iloc[rr,:]
    igbp = row['igbp']        
    di_colors = row['di_colors']
    wue_colors = row['wue_colors']
    di_ncolor = tuple(c / 255.0 for c in di_colors[:3])   #根据字典索引指定颜色
    wue_ncolor = tuple(c / 255.0 for c in wue_colors[:3])
    # 形成新的包含RGBA的元组
    di_ncolor_alpha = (di_ncolor[0], di_ncolor[1], di_ncolor[2], di_colors[3])
    wue_ncolor_alpha = (wue_ncolor[0], wue_ncolor[1], wue_ncolor[2], wue_colors[3])
    sc1 = ax1.scatter(row['lon'], row['lat'], c = di_ncolor_alpha, 
                    s=150, edgecolor='k', marker=shape_dict[igbp], transform=ccrs.PlateCarree())  #绘制散点图
    sc2 = ax2.scatter(row['lon'], row['lat'], c = wue_ncolor_alpha, 
                    s=150, edgecolor='k', marker=shape_dict[igbp], transform=ccrs.PlateCarree())
   
plt.show()
fig.savefig("F:/phd1/V8/01allsite/03trend/latlon_euro.jpg",dpi=300, format='jpg', bbox_inches='tight')
