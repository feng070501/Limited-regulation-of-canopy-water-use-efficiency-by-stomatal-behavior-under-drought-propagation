# -*- coding: utf-8 -*-
"""
Created on Mon Oct 21 10:58:24 2024

@author: LF
"""
'''本程序用于计算变量本身的异常和它们的SPEI和SMDI阈值之间的关系'''
'''注意更换4/5/6阶段'''
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import linregress, t
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
def plot_regression(ax, df, title, xlabel, ylabel):
    x = df.iloc[:, 0]
    y = df.iloc[:, 1]    
    # 进行线性回归
    slope, intercept, r_value, p_value, std_err = linregress(x, y)
    regression_line = slope * x + intercept     
    #r_squared = r_value ** 2  # 计算R²
    # 输出回归方程和R²
    equation_text = f"y = {slope:.2f} * x + {intercept:.2f}"
    #r2_text = f"R² = {r_value:.2f}"
    p_text = f"P = {p_value:.2f}"  
    
    # 绘制散点图和回归线    
    sns.regplot(x=x, y=y, ci=95, ax=ax, color='#FF7043',  # 设置回归线颜色为绿色
            scatter_kws={'color': 'dodgerblue', 'edgecolor':'k', 's': 100, 'alpha': 0.7},)  # ci 参数控制置信区间，默认 95%
    # 写字    
    ax.text(0.65, 0.15, equation_text, transform=ax.transAxes, fontsize=25, verticalalignment='top')
    #ax.text(0.65, 0.1, r2_text, transform=ax.transAxes, fontsize=25, verticalalignment='top')
    ax.text(0.65, 0.05, p_text, transform=ax.transAxes, fontsize=25, verticalalignment='top')
    ax.set_xlim(min(x)-0.1, max(x)+0.1)    
    # 设置标题和标签
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)    
    return slope,intercept
#%%
def amc_ano(varitp, phase):
    csvpath1 = 'F:/phd1/V10/01allsite/07amc/'+varitp+'_tpoint.csv'
    tp = pd.read_csv(csvpath1, index_col=0, header=0)
    tp_smdi = tp[['siteid', 'SMDI']]
    tp_spei = tp[['siteid', 'SPEI']]
    csvpath2 = 'F:/phd1/V10/01allsite/08RF/variy_'+phase+'/'+varitp+'_y'+phase+'.csv'
    wue = pd.read_csv(csvpath2, index_col=0, header=0)
    spei_wue = pd.merge(tp_spei, wue, on='siteid', how='left')  #拼接2个df
    smdi_wue = pd.merge(tp_smdi, wue, on='siteid', how='left')  #拼接2个df
    spei_wue1 = spei_wue.drop_duplicates(subset='siteid', keep='first')  # 去掉重复的siteid，只保留第一次出现的
    smdi_wue1 = smdi_wue.drop_duplicates(subset='siteid', keep='first')  # 去掉重复的siteid，只保留第一次出现的
    spei_wue1.set_index('siteid', inplace=True)
    smdi_wue1.set_index('siteid', inplace=True)
    spei_wue2 = spei_wue1.dropna(axis=0,how='any')
    smdi_wue2 = smdi_wue1.dropna(axis=0,how='any')
    #创建子图
    parameters = {'axes.labelsize': 30,
              'axes.titlesize': 35,
              'xtick.labelsize': 25,
              'ytick.labelsize': 25,
              'figure.dpi': 300,
              'lines.linewidth': 3,
              'font.family': 'Arial',
              'axes.titlepad': 20}
    plt.rcParams.update(parameters)
    fig, axes = plt.subplots(nrows=2, ncols=1, figsize=(10, 15))  # 1行2列的子图
    upper_varitp = varitp.upper()
    slope1,intercept1 = plot_regression(axes[0], spei_wue2, '', 'θ$_{'+upper_varitp+'(SPEI)}$',upper_varitp+ ' anomaly in phase '+phase)
    slope2,intercept2 = plot_regression(axes[1], smdi_wue2, '', 'θ$_{'+upper_varitp+'(SMDI)}$',upper_varitp+' anomaly in phase '+phase)
    plt.tight_layout()
    plt.show()
    fig.savefig('F:/phd1/V10/01allsite/07amc/'+varitp+'_'+phase+'.jpg',dpi=300, format='jpg', bbox_inches='tight')
amc_ano('gc', '5')
amc_ano('gc', '4')
amc_ano('gc', '6')
amc_ano('gpp', '5')
amc_ano('gpp', '4')
amc_ano('gpp', '6')
amc_ano('t', '5')
amc_ano('t', '4')
amc_ano('t', '6')
amc_ano('et', '5')
amc_ano('et', '4')
amc_ano('et', '6')
#%%单一示例
csvpath1 = 'F:/phd1/V10/01allsite/07amc/gc_tpoint.csv'
tp = pd.read_csv(csvpath1, index_col=0, header=0)
tp_smdi = tp[['siteid', 'SMDI']]
tp_spei = tp[['siteid', 'SPEI']]
csvpath2 = 'F:/phd1/V10/01allsite/08RF/variy_6/iwue_y6.csv'
wue = pd.read_csv(csvpath2, index_col=0, header=0)
spei_wue = pd.merge(tp_spei, wue, on='siteid', how='left')  #拼接2个df
smdi_wue = pd.merge(tp_smdi, wue, on='siteid', how='left')  #拼接2个df
spei_wue1 = spei_wue.drop_duplicates(subset='siteid', keep='first')  # 去掉重复的siteid，只保留第一次出现的
smdi_wue1 = smdi_wue.drop_duplicates(subset='siteid', keep='first')  # 去掉重复的siteid，只保留第一次出现的
spei_wue1.set_index('siteid', inplace=True)
smdi_wue1.set_index('siteid', inplace=True)
spei_wue2 = spei_wue1.dropna(axis=0,how='any')
smdi_wue2 = smdi_wue1.dropna(axis=0,how='any')
#创建子图
parameters = {'axes.labelsize': 30,
          'axes.titlesize': 35,
          'xtick.labelsize': 25,
          'ytick.labelsize': 25,
          'figure.dpi': 300,
          'lines.linewidth': 3,
          'font.family': 'Arial',
          'axes.titlepad': 20}
plt.rcParams.update(parameters)
fig, axes = plt.subplots(nrows=2, ncols=1, figsize=(10, 15))  # 1行2列的子图
slope1,intercept1 = plot_regression(axes[0], spei_wue2, '', 'θ$_{gc~SPEI}$','iwue anomaly in phase 6')
slope2,intercept2 = plot_regression(axes[1], smdi_wue2, '', 'θ$_{gc~SMDI}$','iwue anomaly in phase 6')
plt.tight_layout()
plt.show()
