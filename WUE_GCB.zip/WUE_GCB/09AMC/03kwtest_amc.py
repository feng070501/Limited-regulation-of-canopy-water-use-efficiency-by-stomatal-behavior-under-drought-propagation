# -*- coding: utf-8 -*-
"""
Created on Mon Oct 21 20:11:43 2024

@author: LF
"""
'''本程序用于进行各组之间的Kruskal-Wallis检验。'''
#注意更改多处IGBP
import glob
import os
import pandas as pd
import numpy as np
from scipy.stats import kruskal
from scikit_posthocs import posthoc_dunn
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
def generate_cld(p_df, alpha=0.05):
    """
    根据 p 值矩阵生成简化字母显示（Compact Letter Display）。
    输入：
      - p_df: DataFrame，行和列为各组，值为两两比较的 p 值
      - alpha: 显著性水平（默认 0.05）
    输出：
      - cld: dict，键为组名，值为对应的字母字符串
    """
    groups = list(p_df.index)
    n = len(groups)
    
    # 构造一个二元矩阵：若 p >= alpha 则认为两组无显著差异
    # 同时将对角线设为 True（组与自身总是相似的）
    ns = (p_df >= alpha).values
    np.fill_diagonal(ns, True)
    
    # 保存每个字母代表的组的索引列表
    letter_groups = []
    # 存放每个组对应的字母集合
    cld = {group: set() for group in groups}
    
    # 逐个组分配字母（顺序可以依据组的某个统计量排序，比如中位数，这里直接按原顺序）
    for i, group in enumerate(groups):
        assigned = False
        # 尝试已有的字母
        for li, group_indices in enumerate(letter_groups):
            # 检查当前组与该字母下所有组之间是否无显著差异
            if all(ns[i, j] for j in group_indices):
                # 如果符合条件，则将该组添加到该字母分组中
                group_indices.append(i)
                cld[group].add(li)
                assigned = True
        # 如果没有合适的字母，则新建一个字母
        if not assigned:
            letter_groups.append([i])
            cld[group].add(len(letter_groups)-1)
    
    # 将字母编号转换为字母，例如 0->a, 1->b, ...
    cld_str = {group: ''.join(sorted(chr(ord('a')+l) for l in cld[group])) for group in groups}
    return cld_str
#%%
vari_list = ['gc','et','gpp','t']
dfs = []
for vv in vari_list:
    dd = f'F:/phd1/V10/01allsite/07amc/{vv}_tpoint1.csv'    
    file_name = os.path.splitext(os.path.basename(dd))[0]
    data_frame = pd.read_csv(dd, index_col=0, header=0)
    data_frame1 = data_frame.dropna() #去掉nan
    #data_frame2 = data_frame1.drop_duplicates(subset='siteid', keep='first')  # 去掉重复的siteid，只保留第一次出现的
    data_frame3 = data_frame1.reset_index(drop=True)  #重置index
    data_frame3.columns = [f'{file_name}_{col}' for col in data_frame3.columns]   #修改columns 
    dfs.append(data_frame3)
combined_df = pd.concat(dfs, axis=1)
columns_to_drop = combined_df.filter(regex='siteid$').columns  # 过滤出以 "siteid" 结尾的列名
combined_df1 = combined_df.drop(columns=columns_to_drop)   # 删除这些列
combined_df1.dropna(inplace=True)      
#Kruskal-Wallis检验
hstat, p_value = kruskal(*[combined_df1[col] for col in combined_df1.columns])
print(f'Kruskal-Wallis 检验结果: H-statistic={hstat}, p-value={p_value}')
if p_value < 0.05:
    # 如果存在显著差异，进行Dunn's检验
    dunn = posthoc_dunn([combined_df1[col] for col in combined_df1.columns], p_adjust='bonferroni')
    dunn.index = combined_df1.columns
    dunn.columns = combined_df1.columns
    mask = np.triu(np.ones(dunn.shape), k=1).astype(bool)
    dunn_lower_triangle = dunn.mask(mask) #只保留下三角    
    dunn_lower_triangle.to_excel(f'F:/phd1/V10/01allsite/07amc/box_dunn1.xlsx', index=True, header=True, float_format='%.4f')
    cld_labels = generate_cld(dunn, alpha=0.05)
    cld_df = pd.DataFrame(list(cld_labels.items()), columns=['Group', 'CLD'])
    # 将 DataFrame 写入 Excel 文件，不保存行索引
    cld_df.to_excel('F:/phd1/V10/01allsite/07amc/cld_labels1.xlsx', index=False)
# 按照均值从大到小排序，并获取列名
mean_values = combined_df1.mean().sort_values(ascending=False)
sorted_mean = mean_values.reset_index()
sorted_mean.columns = ['Column', 'Mean']    
sorted_mean.to_excel(f'F:/phd1/V10/01allsite/07amc/box_sorted1.xlsx', index=False)

