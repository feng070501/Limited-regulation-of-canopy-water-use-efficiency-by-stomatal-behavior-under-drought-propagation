# -*- coding: utf-8 -*-
"""
Created on Sun Jun 22 21:25:37 2025

@author: LF
"""
'''本程序用于将计算的干旱阈值按照IGBP分类'''
import os
import glob
import numpy as np
import pandas as pd
from functools import reduce
#%%
info_path = 'F:/phd1/V10/01allsite/02drought/SPEI_scale.xlsx'
site_frame = pd.read_excel(info_path, index_col=0, header=0)
dfs = []
dir_path = 'F:/phd1/V10/01allsite/07amc/'
file_list = ['Gc_tpoint.csv', 'GPP_tpoint.csv','ET_tpoint.csv','T_tpoint.csv']
for filetext in file_list:
    amc_path = os.path.join(dir_path, filetext)
    filename = os.path.splitext(os.path.basename(amc_path))[0]
    vari = filename.split('_')[0]  # 按/分割
    amc_df = pd.read_csv(amc_path, index_col=0, header=0)
    amc_df1 = amc_df.rename(columns={col: f"{vari}_{col}" for col in amc_df.columns if col != 'siteid'})
    dfs.append(amc_df1)
df_merged = reduce(lambda left, right: pd.merge(left, right, on='siteid', how='outer'), dfs)
df_merged1 = df_merged.merge(site_frame[['siteid', 'igbp']], on='siteid', how='left')
df_merged2 = df_merged1.drop_duplicates(subset='siteid', keep='first')
for igbp_name, group_df in df_merged2.groupby('igbp'):
    # 删除 igbp 列
    group_df = group_df.drop(columns='igbp')
    # 保存为 CSV 文件，文件名就是 igbp 的取值
    group_df.to_csv(f'F:/phd1/V10/{igbp_name}/01multisite/04amc/tp_point.csv', index=False)



