# -*- coding: utf-8 -*-
"""
Created on Wed Apr 24 10:23:49 2024

@author: LF
"""
'''本程序用于对数据按干旱过程进行分组。'''
#注意更改IGBP
import os
import re
import glob 
import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息

#%%
dir_list = glob.glob(r'F:/phd1/V10/*/*/06WUE/')
dfs = []
for dd in dir_list:
    dd = dd.replace('\\', '/')
    substrings = re.split(r'/', dd)  # 按/分割
    igbp = substrings[3]
    siteid = substrings[4]    
    csvpath4 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/03data_flt/data_zscflt.csv'
    ori_frame = pd.read_csv(csvpath4, index_col=0, parse_dates=True, header=0)
    et_frame = ori_frame['t_et'].to_frame()    
    csvpath5 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/05SMDI/spei_smdi.csv'
    spei_smdi = pd.read_csv(csvpath5, index_col=0, parse_dates=True, header=0)
    di_frame = pd.DataFrame(spei_smdi["DI"])   
    common_df = pd.merge(di_frame, et_frame, how='inner', left_index=True, right_index=True) #取交集合并各dataframe    
    common_df.dropna(inplace=True) #删除nan位置所在的元素
    dfs.append(common_df)
    print(siteid)
combined_df = pd.concat(dfs, axis=0) # 使用pd.concat函数进行上下合并
combined_df.reset_index(drop=True, inplace=True)   # 重置索引（可选），以使合并后的DataFrame有连续的索引      
grouped = combined_df.groupby('DI') # 使用groupby函数按第一列分组    
for group_name, group_data in grouped: # 遍历每个组并输出对应的样本
    group_data.to_csv('F:/phd1/V10/01allsite/04group/group'+str(int(group_name))+'_tet.csv', index=True, header=True, float_format='%.4f')
    
    
    
