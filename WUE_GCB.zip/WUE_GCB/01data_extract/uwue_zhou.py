import numpy as np
from scipy.optimize import minimize

def rain_mask(pre):  #去除雨天
    mask = pre.values <= 0.1
    #遍历布尔索引，并将满足条件的元素之后的两个元素赋值为 NaN
    for i in range(len(mask)):
        if pre.values[i] >= 0.1:  # 如果当前元素大于0.1
            # 将当前元素及之后的两个元素赋值为 NaN
            mask[i:i + 3] = False
    return mask

def zhouFlags_daily(dsIN):
    """
    生成大于0、质量控制、降水和生长季掩码，适用于日级时间序列数据。    
    参数：
        dsIN: 输入数据集，包含每日分辨率的变量            
    返回：
        uWUEa_Mask: 仅基于质量和零值过滤的掩码
        uWUEp_Mask: 进一步基于降水和生长季过滤的掩码
    """
    ds = dsIN.copy()
    # 初始化掩码    
    zeroMask = np.ones(ds['et'].shape).astype(bool)
    # 构建 zeroMask
    for var in ['rnet', 'vpd']:
        zeroMask &= (ds[var].values > 0)
    # 构建 seasonMask
    GPPday = ds['gpp'].values
    seasonThreshold = 0.10 * np.nanpercentile(GPPday, 95)
    seasonMask = GPPday > seasonThreshold
    # 构建 precipMask
    precipMask = rain_mask(ds['pre'])
    # 结合掩码
    uWUEa_Mask = zeroMask
    uWUEp_Mask = zeroMask & precipMask & seasonMask

    return uWUEa_Mask, uWUEp_Mask

def quantreg(x, y, PolyDeg=1, rho=0.95, weights=None):
    """
    Perform quantile regression using a polynomial model.
    
    Parameters
    ----------
    x : array-like
        Independent variable (自变量).
    y : array-like
        Dependent variable (因变量).
    PolyDeg : int, optional
        The degree of the polynomial function (default is 1).
    rho : float, optional
        Quantile to fit (default is 0.95), must be between 0 and 1.
    weights : array-like, optional
        Weights for each point (default is None, treated as equal weights).
    
    Returns
    -------
    np.ndarray
        Estimated coefficients of the polynomial, ordered from low to high degree.
    """
    # x = np.asarray(x)
    # y = np.asarray(y)
    if weights is None:
        weights = np.ones_like(x)

    def model(x, beta):
        """
        Polynomial model function.
        """
        if PolyDeg == 0:
            return x*beta
        else:
            return np.polyval(beta, x)  # Reverse beta for compatibility with np.polyval

    def tilted_abs(rho, residuals, weights):
        """
        Compute the tilted absolute value function for quantile regression.
        """
        return weights * residuals * (rho - (residuals < 0))
    def objective(beta):
        """
        Objective function to minimize: sum of tilted absolute values of residuals.
        """
        residuals = y - model(x, beta)
        return tilted_abs(rho, residuals, weights).sum()
    # Initial guess for coefficients
    beta_0 = np.zeros(PolyDeg + 1)
    if PolyDeg >= 1:
        beta_0[1] = 1.0  # Set linear term to non-zero as a starting point
    # Perform minimization
    result = minimize(objective, beta_0, method='Powell', 
                      options={'disp': False, 'maxiter': 10000, 'xtol': 1e-8})    
    if not result.success:
        raise ValueError(f"Optimization failed: {result.message}")    
    return result.x


def zhou_part_daily(ET, GxV, uWUEa_Mask, uWUEp_Mask, rho=0.95):
    '''
    zhou_part_daily(ET, GxV, uWUEa_Mask, uWUEp_Mask, rho=0.95)

    ET partitioning based on Zhou et al. 2016, adapted for daily time series.

    Parameters
    ----------
    ET : array
        Daily evapotranspiration (mm per day)
    GxV : array
        GPP*VPD^0.5 in (gC hPa^0.5 m^-2 d^-1)
    uWUEa_Mask : bool array
        Boolean array where True indicates days to be included when calculating uWUEa
    uWUEp_Mask : bool array
        Boolean array where True indicates days to be included when calculating uWUEp
    rho : float between 0-1
        The percentile to fit to, must be between 0-1

    Returns
    -------
    zhou_T : array
        Estimated transpiration (mm per day)
    '''
    # Ensure masks are valid
    uWUEa_Mask = np.isfinite(ET) & np.isfinite(GxV) & uWUEa_Mask
    uWUEp_Mask = np.isfinite(ET) & np.isfinite(GxV) & uWUEp_Mask

    # Calculate uWUEp using quantile regression
    uWUEp = quantreg(ET[uWUEp_Mask], GxV[uWUEp_Mask], PolyDeg=0, rho=rho)[0]

    # Calculate uWUEa for daily data
    uWUEa = np.full(ET.shape[0], np.nan)  # Initialize with NaN
    ET = np.asarray(ET)
    GxV = np.asarray(GxV)
    for j in range(ET.shape[0]):
        if uWUEa_Mask[j]:  # Only process days within the mask
            x = ET[j:j+1][:, np.newaxis]  # Reshape for lstsq
            y = GxV[j:j+1][:, np.newaxis]
            a1, _, _, _ = np.linalg.lstsq(x, y, rcond=None)
            uWUEa[j] = a1

    # Calculate daily transpiration fraction (T/ET)
    ToET_daily = uWUEa / uWUEp
    zhou_T = ET * ToET_daily
    
    return zhou_T

