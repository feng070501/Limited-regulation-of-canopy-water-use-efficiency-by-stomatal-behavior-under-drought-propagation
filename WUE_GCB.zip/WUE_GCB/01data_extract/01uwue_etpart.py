# -*- coding: utf-8 -*-
"""
Created on Wed Jan 22 09:35:39 2025

@author: LF
"""
'''本程序用于分割ET，并求T/ET。'''
#注意修改IGBP
import uwue_zhou as uwue
import numpy as np
import pandas as pd
import glob
import re
#%%
dir_list = glob.glob('F:/phd1/V6/SAV/*/01data_dd/data_ori.csv')
for dd in dir_list:
    dd = dd.replace('\\', '/')
    substrings = re.split(r'/', dd)  # 按/分割
    igbp = substrings[3]
    siteid = substrings[4]
    ori = pd.read_csv(dd, index_col=0, parse_dates=True, header=0)
    et = ori.et
    gxv = ori.gpp * ori.vpd **0.5
    uWUEa_Mask, uWUEp_Mask = uwue.zhouFlags_daily(ori)
    uWUEp = uwue.quantreg(et[uWUEp_Mask], gxv[uWUEp_Mask], PolyDeg=0, rho=0.95)[0]
    t_uwue = uwue.zhou_part_daily(et, gxv, uWUEa_Mask, uWUEp_Mask, rho=0.95)
    t_uwue1 = pd.Series(t_uwue, index = et.index, name='t')
    t_et = t_uwue1/ori.et
    ori['t'] = t_uwue1
    ori['t_et'] = t_et*100
    ori.to_csv('F:/phd1/V6/'+igbp+'/'+siteid+'/01data_dd/data_ori.csv', float_format='%.4f')
    print(siteid)
