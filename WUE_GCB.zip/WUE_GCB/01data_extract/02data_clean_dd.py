# -*- coding: utf-8 -*-
"""
Created on Sun Apr 21 20:54:23 2024

@author: LF
"""
'''针对提取出的通量站点各变量数据进行清洗。'''
#注意修改IGBP
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import signal
from scipy.fftpack import fft, fftfreq
from scipy.stats import zscore
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.stattools import acf
import glob
import os
import re
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
# def calc_zsc(df, var):  #求Z score
#     df.replace([np.inf, -np.inf], np.nan, inplace=True)
#     nan_locs = df[var].isna()   #找出 NaN 的位置    
#     df_nonan = df.dropna()    #去掉 NaN 值    
#     df_nonan['dayofyear'] = df_nonan.index.dayofyear   # 添加dayofyear列
#     # 计算每一天的多年平均值和标准差，忽略 NaN 值
#     daily_average = df_nonan.groupby('dayofyear')[var].mean()
#     daily_std = df_nonan.groupby('dayofyear')[var].std()
#     # 将多年平均值合并回原始 DataFrame
#     df_nonan = df_nonan.join(daily_average, on='dayofyear', rsuffix='_mean')
#     df_nonan = df_nonan.join(daily_std, on='dayofyear', rsuffix='_std')    
#     df_nonan['anomaly'] = np.nan_to_num((df_nonan[var] - df_nonan[var+'_mean']) / df_nonan[var+'_std']) # 计算异常值   
#     df_final = df.copy()
#     df_final.loc[~nan_locs, df.columns] = df_nonan['anomaly']  #将去趋势后的数据插入回原来的 DataFrame 中，同时保留 NaN 值
#     df_zsc = df_final.squeeze()    
#     return df_zsc   
def my_detrend(df, var):
    df.replace([np.inf, -np.inf], np.nan, inplace=True)
    df['day_of_year'] = df.index.day_of_year    
    nan_locs = df[var].isna()   #找出 NaN 的位置    
    df_nonan = df.dropna()    #去掉 NaN 值    
    # 去除 NaN 后按 day_of_year 计算均值
    mean_per_day = df_nonan.groupby('day_of_year')[var].mean()
    # 使用多项式拟合季节性周期
    degree = 5  # 选择多项式的阶数
    coeffs = np.polyfit(mean_per_day.index, mean_per_day.values, degree)  # 多项式拟合
    poly_model = np.poly1d(coeffs)
    df_nonan['seasonal_fit'] = poly_model(df_nonan['day_of_year'])
    
    detrended_values = signal.detrend(df_nonan[var])   #去趋势   
    deseasonal_values = detrended_values - df_nonan['seasonal_fit'].values #去季节性
    df_dets = pd.DataFrame(deseasonal_values, index=df_nonan.index, columns=[var])    #创建去趋势季节后的 DataFrame   
    df_final = df[var].to_frame().copy()
    df_final.loc[~nan_locs, var] = df_dets[var]  #将去趋势季节后的数据插入回原来的 DataFrame 中，同时保留 NaN 值
    return df_final
def rain_filter(pre):  #去除雨天
    mask = pre.values <= 0.1
    # 遍历布尔索引，并将满足条件的元素之后的两个元素赋值为 NaN
    for i in range(len(mask)):
        if pre.values[i] >= 0.1:  # 如果当前元素大于0.1
            # 将当前元素及之后的两个元素赋值为 NaN
            mask[i:i + 2] = False
    return mask
#%%
dir_list = glob.glob(r'F:/phd1/V8/*/*/01data_dd/data_ori.csv')
for dd in dir_list:
    dd = dd.replace('\\', '/')
    substrings = re.split(r'/', dd)  # 按/分割
    igbp = substrings[3]
    siteid = substrings[4]    
    ori = pd.read_csv(dd, index_col=0, parse_dates=True, header=0)          
    #对数据进行过滤
    gpp = ori.gpp
    gpp_95 = np.nanpercentile(gpp.values, 95)       #95%分位数
    # 计算5天滑动平均温度（需要完整5天数据
    ta = ori['ta']
    
    gpp_mask = gpp.values > (0.1*gpp_95)
    #growth_mask = temp_mask | gpp_mask  #只要 temp_mask 或 gpp_mask 中有一个为 True，growth_mask 就为 True
    sun_mask = (ori['rnet'].values > 0) & (ori['vpd'].values > 1)
    rain_mask = rain_filter(ori['pre'])
    close_mask = np.ones(ori.shape[0]).astype(bool)
    rnet = ori.rnet
    le = ori['le']
    he = ori.he
    try:  #Chinaflux没有土壤热通量
        gf = ori.gf
        delta = np.abs(rnet.values - gf.values- le.values - he.values)
        if np.isnan(delta).all():
            close_mask = np.ones_like(close_mask, dtype=bool)        
        else:
            for rr in range(rnet.shape[0]):
                if np.abs(delta[rr]) > 0.5 * np.abs(rnet.values[rr] - gf.values[rr]):
                    close_mask[rr] = False                              
    except:       
        close_mask = np.ones_like(close_mask, dtype=bool)
    all_mask = gpp_mask & sun_mask & rain_mask & close_mask
    # 指定需要掩膜的列
    columns_to_mask = ['le', 'et', 'gpp','t','t_et']
    # 扩展 mask 的形状，使其与指定列的子 DataFrame 匹配
    mask_expanded = np.tile(all_mask, (len(columns_to_mask), 1)).T  # 广播转置后每列对应 mask
    # 创建新的DataFrame，并对特定列应用掩膜
    df_mask = ori.copy()
    df_mask[columns_to_mask] = df_mask[columns_to_mask].where(mask_expanded, np.nan)  # 掩膜为False的地方设为NaN
    t_etmask = ori.t_et.values <= 100
    columns_to_mask1 = ['t','t_et']
    mask_expanded1 = np.tile(t_etmask, (len(columns_to_mask1), 1)).T  # 广播转置后每列对应 mask
    df_mask1 = df_mask.copy()
    df_mask1[columns_to_mask1] = df_mask1[columns_to_mask1].where(mask_expanded1, np.nan)
    #去趋势去季节
    zsc = pd.DataFrame(index = df_mask1.index, columns= df_mask1.columns)
    vari_list = df_mask1.columns
    for vv in vari_list:                    
        try:  #变量均为空
            df_mask1_col = df_mask1[vv].to_frame()       
            dtr = my_detrend(df_mask1_col,vv)  # 去趋势
            #zsc_col = calc_zsc(dtr, vv) #算zsc
            zsc_col = zscore(dtr[vv], nan_policy='omit')
            # 将大于 5 的元素替换为 NaN
            zsc_col[zsc_col > 5] = np.nan
            zsc[vv] = zsc_col
        except TypeError as e:
            pass
    zsc.to_csv('F:/phd1/V8/'+igbp+'/'+siteid+'/03data_flt/data_zscflt.csv', float_format='%.4f')
    #绘制散点图
    parameters = {'axes.labelsize': 30,
              'axes.titlesize': 30,
              'xtick.labelsize': 30,
              'ytick.labelsize': 30,
              'figure.dpi': 300,
              'lines.linewidth': 4,
              'font.family': 'Times New Roman'}
    plt.rcParams.update(parameters)
    sup_map = str.maketrans('23456789', '²³⁴⁵⁶⁷⁸⁹')#设置上标
    fig, axs = plt.subplots(3, 1, figsize=(22, 12), dpi=300)
    index1 = zsc.index
    axs[0].scatter(index1, zsc.et, color='#82b4d1')
    axs[0].set_title(f'(a) {siteid} ET')
    axs[0].set_ylabel('mm d-1', fontsize=30,y=0.8)  # 设置y轴刻度标签
    axs[1].scatter(index1, zsc.t, color='#e0b7b7')
    axs[1].set_title(f'(b) {siteid} T')
    axs[1].set_ylabel('mm d-1'.translate(sup_map), fontsize=30, y=0.8)  # 设置y轴刻度标签
    axs[2].scatter(index1, zsc.gpp, color='#e0b7b7')
    axs[2].set_title(f'(c) {siteid} GPP')
    axs[2].set_ylabel('gC m-2 d-1'.translate(sup_map), fontsize=30, y=0.8)  # 设置y轴刻度标签
    for i in range(3):
        axs[i].spines['top'].set_linewidth(2)  # 设置顶部边框粗细为2
        axs[i].spines['bottom'].set_linewidth(2)  # 设置底部边框粗细为2
        axs[i].spines["right"].set_color(None)# 去掉右边框
        axs[i].spines["top"].set_color(None)# 去掉上边框
        axs[i].grid(True,axis='y',c='lightgray',ls='--') #设置网格线
    # 调整子图之间的间距
    plt.tight_layout()
    plt.show()
    print(siteid)
#%%



