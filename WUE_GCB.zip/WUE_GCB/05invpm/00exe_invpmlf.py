# -*- coding: utf-8 -*-
"""
Created on Tue Apr 23 21:56:20 2024

@author: LF
"""
'''本程序用于执行反彭曼公式。'''
#更改IGBP
import os
os.chdir('E:/spyder_space/phd1/codeV7/06invpm')
import glob
import re
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import invpmlf as pm
import warnings
#%%
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
dir_list = glob.glob(r'F:/phd1/V7/*/*/01data_dd/data_ori.csv')
for dd in dir_list:
    dd = dd.replace('\\', '/')
    substrings = re.split(r'/', dd)  # 按/分割
    igbp = substrings[3]
    siteid = substrings[4]
    #os.makedirs('F:/FLUX/V7/'+igbp+'/'+siteid+'/06WUE/', exist_ok=True)
    ori = pd.read_csv(dd, index_col=0, parse_dates=True, header=0)
    ta = ori.ta.values    
    #le = ori['le'].values
    rnet = ori.rnet.values
    vpd = ori.vpd_pa.values
    press = ori.pa_pa.values
    ws = ori.ws.values
    cols = ori.columns.to_list()
    he = ori.he.values
    t = ori['t'].values
    # 计算lamda
    lamda = 2.501 - 2.361e-3 * ta    
    # 已知 et，计算 le
    le_pot = t * lamda / (86400 * 1e-6)
#    
    if 'gf' in cols: #有没有土壤热通量
        gf = ori.gf.values          
        if 'ustar' in cols: #有没有摩擦速度
            ustar = ori.ustar.values            
            ga = pm.calc_ga(ch = None, u = ws, zm = None, zh = None, ustar = ustar)
            delta = pm.cala_delta(ta)
            rho = pm.calc_rho(press, ta)
            gamma = pm.calc_gam(press, ta)
            cp = 1012
            if np.isnan(gf).all():
                gc_mol = pm.calc_gc(le=le_pot, rnet=rnet, gf=None, he=he, vpd=vpd, gamma=gamma, ga=ga, delta=delta, rho=rho, cp=cp, 
                                    press=press, ta=ta)
            else:
                gc_mol = pm.calc_gc(le=le_pot, rnet=rnet, gf=gf, he=None, vpd=vpd, gamma=gamma, ga=ga, delta=delta, rho=rho, cp=cp, 
                                    press=press, ta=ta)

            gc_mol[gc_mol < 0] = 0            
            gc_mol = np.where(gc_mol > 1, np.nan, gc_mol)#剔除异常值
            gc_mol_df = pd.DataFrame(gc_mol, index=ori.index, columns=["gc"])
            gc_mol_df.to_csv('F:/phd1/V7/'+igbp+'/'+siteid+'/06WUE/gc_ori.csv', float_format='%.4f')  #
            plt.scatter(ori.index, gc_mol)
            plt.title(f'{siteid} gc')
            plt.show()
        else:            
            print(siteid,"摩擦速度路径不存在")
            file_path = glob.glob('F:/phd1/rawdata/*/'+igbp+'/'+siteid+'/siteinfo.txt')  #读取站点冠层高度
            for ff in file_path:
                with open(ff, 'r', encoding='utf-8') as file:
                    lines = file.readlines()
                    text = lines[5].strip().split('m')
                    ch = np.float64(text[0])  # 站点经度
                zm = zh = ch * 1.5
            ch_arr = np.full((len(le_pot), 1), ch).flatten()
            zm_arr = zh_arr = np.full((len(le_pot), 1), zh).flatten()
            ga = pm.calc_ga(ch = ch_arr, u = ws, zm = zm_arr, zh = zh_arr, ustar = None)
            delta = pm.cala_delta(ta)
            rho = pm.calc_rho(press, ta)
            gamma = pm.calc_gam(press, ta)
            cp = 1012
            if np.isnan(gf).all():
                gc_mol = pm.calc_gc(le=le_pot, rnet=rnet, gf=None, he=he, vpd=vpd, gamma=gamma, ga=ga, delta=delta, rho=rho, cp=cp, 
                                    press=press, ta=ta)
            else:
                gc_mol = pm.calc_gc(le=le_pot, rnet=rnet, gf=gf, he=None, vpd=vpd, gamma=gamma, ga=ga, delta=delta, rho=rho, cp=cp, 
                                    press=press, ta=ta)
            gc_mol[gc_mol < 0] = 0            
            gc_mol = np.where(gc_mol > 1, np.nan, gc_mol)#剔除异常值
            gc_mol_df = pd.DataFrame(gc_mol, index=ori.index, columns=["gc"])
            gc_mol_df.to_csv('F:/phd1/V7/'+igbp+'/'+siteid+'/06WUE/gc_ori.csv', float_format='%.4f')  #
            plt.scatter(ori.index, gc_mol)
            plt.title(f'{siteid} gc')
            plt.show()
    else:
        if 'ustar' in cols:
            ustar = ori.ustar.values
            ga = pm.calc_ga(ch = None, u = ws, zm = None, zh = None, ustar = ustar)
            delta = pm.cala_delta(ta)
            rho = pm.calc_rho(press, ta)
            gamma = pm.calc_gam(press, ta)
            cp = 1012            
            gc_mol = pm.calc_gc(le=le_pot, rnet=rnet, gf=None, he=he, vpd=vpd, gamma=gamma, ga=ga, delta=delta, rho=rho, cp=cp, 
                                    press=press, ta=ta)            
            gc_mol[gc_mol < 0] = 0            
            gc_mol = np.where(gc_mol > 1, np.nan, gc_mol)#剔除异常值
            gc_mol_df = pd.DataFrame(gc_mol, index=ori.index, columns=["gc"])
            gc_mol_df.to_csv('F:/phd1/V7/'+igbp+'/'+siteid+'/06WUE/gc_ori.csv', float_format='%.4f')  #
            plt.scatter(ori.index, gc_mol)
            plt.title(f'{siteid} gc')
            plt.show()
        else:            
            print(siteid,"摩擦速度路径不存在")
            file_path = glob.glob('F:/phd1/rawdata/*/'+igbp+'/'+siteid+'/siteinfo.txt')  #读取站点冠层高度
            for ff in file_path:
                with open(ff, 'r', encoding='utf-8') as file:
                    lines = file.readlines()
                    text = lines[5].strip().split('m')
                    ch = np.float64(text[0])  # 站点经度
                zm = zh = ch * 1.5
            ch_arr = np.full((len(le_pot), 1), ch).flatten()
            zm_arr = zh_arr = np.full((len(le_pot), 1), zh).flatten()
            ga = pm.calc_ga(ch = ch_arr, u = ws, zm = zm_arr, zh = zh_arr, ustar = None)
            delta = pm.cala_delta(ta)
            rho = pm.calc_rho(press, ta)
            gamma = pm.calc_gam(press, ta)
            cp = 1012            
            gc_mol = pm.calc_gc(le=le_pot, rnet=rnet, gf=None, he=he, vpd=vpd, gamma=gamma, ga=ga, delta=delta, rho=rho, cp=cp, 
                                    press=press, ta=ta)        
            gc_mol[gc_mol < 0] = 0            
            gc_mol = np.where(gc_mol > 1, np.nan, gc_mol)#剔除异常值
            gc_mol_df = pd.DataFrame(gc_mol, index=ori.index, columns=["gc"])
            gc_mol_df.to_csv('F:/phd1/V7/'+igbp+'/'+siteid+'/06WUE/gc_ori.csv', float_format='%.4f')  #
            plt.scatter(ori.index, gc_mol)
            plt.title(f'{siteid} gc')
            plt.show()

