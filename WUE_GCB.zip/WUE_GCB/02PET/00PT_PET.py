# -*- coding: utf-8 -*-
"""
Created on Fri Apr 12 16:17:56 2024

@author: LF
"""
'''本程序用于计算基于PT的daily PET。'''
#注意更改IGBP
import glob
import os
import re
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import Priestly_Taylor as PT
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%计算PET
os.chdir('E:/spyder_space/phd1/codeV6/03PET')
dir_list = glob.glob(r'F:/phd1/V6/SHR/*/01data_dd/data_ori.csv')
info_path = 'F:/phd1/V6/01allsite/01siteinfo/siteinfo_dem.csv'
site_frame = pd.read_csv(info_path, index_col=0, header=0)
for dd in dir_list:
    try:
        dd = dd.replace('\\', '/')
        substrings = re.split(r'/', dd)  # 按/分割
        igbp = substrings[3]
        siteid = substrings[4]
        #os.makedirs('F:/phd1/V6/'+igbp+'/'+siteid+'/04SPEI/', exist_ok=True)        
        ori = pd.read_csv(dd, index_col=0, parse_dates=True, header=0)
        ta = ori['ta'].values    
        swin = ori.swin.values    
        pa = ori.pa.values
        gf = ori['gf'].values
        ele = site_frame.loc[site_frame['siteid'] == siteid, 'ele'].values[0]
        lat = site_frame.loc[site_frame['siteid'] == siteid, 'lat'].values[0]
        _,daylength,_,_ = PT.solar_geom(ele, lat, 0.0065)#计算日照时长，输入海拔、纬度和递减率常数
        doy = pd.DataFrame(ori.index.dayofyear.tolist(), columns=['doy'])#获取DOY
        daylength1 = pd.DataFrame(daylength, index=list(range(1,367)), columns=['daylength'])
        daylength1['doy'] = list(range(1,367))
        daylength2 = pd.merge(doy, daylength1, on='doy', how='left')#vlookup两个df
        dal = np.array(daylength2['daylength']).flatten()
        pet = PT.calc_pet(swin, ta, dal, gf, pa, 0.2)
        index = ori.index
        pet_df = pd.DataFrame(pet, index=index, columns=['pet'])
        pet_df.to_csv('F:/phd1/V6/'+igbp+'/'+siteid+'/04SPEI/pet_ori.csv', float_format='%.4f')
        print(siteid)
        #绘制散点图
        parameters = {'axes.labelsize': 30,
                  'axes.titlesize': 30,
                  'xtick.labelsize': 30,
                  'ytick.labelsize': 30,
                  'figure.dpi': 300,
                  'lines.linewidth': 4,
                  'font.family': 'Times New Roman'}
        plt.rcParams.update(parameters)
        fig, axs = plt.subplots(1, 1, figsize=(15, 8), dpi=300)
        index1 = pet_df.index
        axs.scatter(index1, pet_df, color='#82b4d1')
        axs.set_title(f'{siteid} PET')
        axs.set_ylabel('mm d-1', fontsize=30,y=0.8)  # 设置y轴刻度标签
        plt.show()
    except:
        pass

