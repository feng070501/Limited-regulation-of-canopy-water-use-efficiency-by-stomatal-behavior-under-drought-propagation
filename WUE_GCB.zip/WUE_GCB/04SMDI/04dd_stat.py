# -*- coding: utf-8 -*-
"""
Created on Mon Sep 16 22:02:46 2024

@author: LF
"""
'''本程序用于统计各站点干旱阶段的占比。'''
#注意更改IGBP
import numpy as np
import pandas as pd
import glob
import re
import os
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
info_path = 'F:/phd1/V10/01allsite/01siteinfo/siteinfo_dem.csv'
site_frame = pd.read_csv(info_path, index_col=0, header=0)
dir_list = glob.glob(r'F:/phd1/V10/*/*/05SMDI/di_percentage.xlsx')
for dd in dir_list:
    dd = dd.replace('\\', '/')
    substrings = re.split(r'/', dd)  # 按/分割
    igbp = substrings[3]
    siteid = substrings[4]        
    di_percentage = pd.read_excel(dd, index_col=0, header=0)   
    try:
        five = di_percentage.loc[6][0] + di_percentage.loc[5][0] + di_percentage.loc[4][0]
        site_frame.loc[site_frame['siteid'] == siteid, 'five_process'] = five    
        print(siteid)
    except KeyError as e:
        pass
site_frame.to_excel('F:/phd1/V10/01allsite/02drought/456_process.xlsx')


