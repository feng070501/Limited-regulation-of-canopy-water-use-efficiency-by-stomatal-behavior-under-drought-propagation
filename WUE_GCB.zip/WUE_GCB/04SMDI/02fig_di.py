# -*- coding: utf-8 -*-
"""
Created on Thu Mar 14 22:21:21 2024

@author: LF
"""
'''本程序用于绘制干旱指数时间序列图'''
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import glob
import re
import os
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%检查标签是否重叠
def rotate_labels(ax):
    # 获取当前的x轴标签
    labels = ax.get_xticklabels()
    # 获取标签的位置
    positions = ax.get_xticks()
    
    # 计算标签的宽度
    label_widths = [label.get_window_extent().width for label in labels]
    
    # 检查标签是否重叠
    overlapping = False
    for i in range(len(labels) - 1):
        if positions[i + 1] - positions[i] < label_widths[i] + label_widths[i + 1]:
            overlapping = True
            break
    
    # 如果标签重叠，则旋转标签；否则不旋转
    if overlapping:
        ax.set_xticklabels(labels, rotation=45, ha='right')
    else:
        ax.set_xticklabels(labels, rotation=0)
#%%
parameters = {'axes.labelsize': 35,
          'axes.titlesize': 55,
          'xtick.labelsize': 35,
          'ytick.labelsize': 45,
          'figure.dpi': 300,
          'lines.linewidth': 4,
          'font.family': 'Arial'}
plt.rcParams.update(parameters)
info_path = 'F:/phd1/V10/01allsite/02drought/SPEI_scale.xlsx'
site_frame = pd.read_excel(info_path, index_col=0, header=0)
dir_list = glob.glob(r'F:/phd1/V10/*/*/01data_dd/data_ori.csv')
for dd in dir_list:
    dd = dd.replace('\\', '/')
    substrings = re.split(r'/', dd)  # 按/分割
    igbp = substrings[3]
    siteid = substrings[4]
    scale = int(site_frame.loc[site_frame['siteid'] == siteid, 'SPEI_scale'].values[0])
    
    ori = pd.read_csv(dd, index_col=0, parse_dates=True, header=0)
    ta_arr = ori.ta.values    
    pre_arr = ori.pre.values 
    csvpath3 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/04SPEI/pet_ori.csv'
    pet_arr = pd.read_csv(csvpath3, index_col=0, parse_dates=True, header=0).values
    csvpath4 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/04SPEI/SPEI'+str(scale*30)+'.csv'
    spei = pd.read_csv(csvpath4, index_col=0, parse_dates=True, header=0).values
    csvpath5 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/05SMDI/SMDI30.csv'
    smdi = pd.read_csv(csvpath5, index_col=0, parse_dates=True, header=0).values
    
    gs = GridSpec(2, 6, width_ratios=[1] * 6, height_ratios=[1, 1])# 创建GridSpec对象，定义不规则的布局
    fig = plt.figure(figsize=(40, 30), dpi = 300)
    # 绘制子图1
    ax1 = fig.add_subplot(gs[0, 0:2])
    ax1.plot(ori.index, ta_arr, lw=4, ls='-', c='#FFBE7A',label='Ta')
    ax1.set(title='(a) Temperature')  # 设置axes及子图标题
    ax1.set_ylabel('°C/d', fontsize=45,y=0.8)  # 设置y轴刻度标签
    # 绘制子图2
    ax2 = fig.add_subplot(gs[0, 2:4])
    ax2.plot(ori.index, pre_arr, lw=4, ls='-', c='#82B0D2',label='Pre')
    ax2.set(title='(b) Precipitation')  # 设置axes及子图标题
    ax2.set_ylabel('mm/d', fontsize=45,y=0.8)  # 设置y轴刻度标签
    # 绘制子图3
    ax3 = fig.add_subplot(gs[0, 4:6])
    ax3.plot(ori.index, pet_arr, lw=4, ls='-', c='#FA7F6F',label='Pet')
    ax3.set(title='(c) PET')  # 设置axes及子图标题
    ax3.set_ylabel('mm/d', fontsize=45,y=0.8)  # 设置y轴刻度标签
    # 绘制子图4
    ax4 = fig.add_subplot(gs[1, 1:3])
    ax4.plot(ori.index, spei, lw=4, ls='-', c='#48D1CC',label='SPEI')
    ax4.set(title=f'(d) {siteid} SPEI')  # 设置axes及子图标题
    # 绘制子图5
    ax5 = fig.add_subplot(gs[1, 3:5])
    ax5.plot(ori.index, smdi, lw=4, ls='-', c='#bfa1d5',label='SMDI')
    ax5.set(title=f'(f) {siteid} SMDI')  # 设置axes及子图标题
    
    for ax in [ax1,ax2,ax3,ax4,ax5]:
        ax.spines['top'].set_linewidth(2)  # 设置顶部边框粗细为2
        ax.spines['bottom'].set_linewidth(2)  # 设置底部边框粗细为2
        ax.spines["right"].set_color(None)# 去掉右边框
        ax.spines["top"].set_color(None)# 去掉上边框
        ax.grid(True,axis='y',c='lightgray',ls='--') #设置网格线
        rotate_labels(ax)
    plt.show()
    plt.tight_layout()# 调整子图间距
    plt.subplots_adjust(hspace=1, wspace=0.7)
    fig.savefig('F:/phd1/V10/'+igbp+'/'+siteid+'/05SMDI/DI.jpg',dpi=300,bbox_inches = 'tight')
    #fig.savefig('F:/phd1/V10/'+igbp+'/'+siteid+'/05SMDI/DI.eps',dpi=300,bbox_inches = 'tight')
    print(siteid)
