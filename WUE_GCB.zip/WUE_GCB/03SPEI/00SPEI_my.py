# -*- coding: utf-8 -*-
"""
Created on Tue Mar  5 18:17:43 2024

@author: LF
"""
'''本程序用于计算SPEI。'''
#注意更改IGBP
import os
import re
import glob
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import indices
import compute
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%计算干旱指数
os.chdir('E:/spyder_space/phd1/codeV6/04SPEI')  #确定运行环境
dir_list = glob.glob(r'F:/phd1/V6/DBF/*/01data_dd/data_ori.csv')
for dd in dir_list:
    dd = dd.replace('\\', '/')
    substrings = re.split(r'/', dd)  # 按/分割
    igbp = substrings[3]
    siteid = substrings[4]    
    ori = pd.read_csv(dd, index_col=0, parse_dates=True, header=0)
    pre_arr = ori.pre.values    
    csvpath1 = 'F:/phd1/V6/'+igbp+'/'+siteid+'/04SPEI/pet_ori.csv'
    pet_arr = pd.read_csv(csvpath1, index_col=0, parse_dates=True, header=0).to_numpy()       
    multiples_of_30 = [i for i in range(30, 361, 30)]  #1~12个月多尺度计算SPEI
    start_year = ori.index[0].year
    end_year = ori.index[-1].year
    for ss in multiples_of_30:
        spei = indices.spei(
                precips_mm= pre_arr, 
                pet_mm= pet_arr,             
                scale= ss, #卷积累加
                distribution= indices.Distribution.gamma,
                periodicity= compute.Periodicity.daily,
                data_start_year= start_year,        
                calibration_year_initial= start_year,
                calibration_year_final= end_year)
        outSPEI=pd.DataFrame(spei, index = ori.index, columns=['SPEI'])
        outSPEI.to_csv('F:/phd1/V6/'+igbp+'/'+siteid+'/04SPEI/SPEI'+str(ss)+'.csv', float_format='%.4f')
    print(siteid)
        
