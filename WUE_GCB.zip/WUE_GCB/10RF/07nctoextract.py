# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 16:40:35 2024

@author: LF
"""
'''本程序用于从nc文件提取有关植被功能性状的统计量'''
import os
import glob
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import rioxarray as rxr
import xarray as xr
import geopandas as gpd
from rasterstats import zonal_stats
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%提取C4
vari = 'C4'
shp_file = "F:/phd1/V6/01allsite/08RF/sitefilter/filter_buffer.shp"
gdf = gpd.read_file(shp_file, encoding='utf-8')    
pft_tif = xr.open_dataset('F:/phd1/V6/01allsite/08RF/rasterdata/PFT/'+vari+'.nc')  #读取tif数据
vari_list = list(pft_tif.variables)   #获取变量
shape_size = pft_tif['C4_area'].shape  #获取尺寸
lat_list = pft_tif.lat.values
backvalue = pft_tif['C4_area'].isel(years = 0, lat=0, lon=0).values
pft_tif.where(pft_tif != backvalue, np.nan)  # 将背景值替换为NaN
vari_mean = pft_tif['C4_area'].mean(dim='years')
# 调整维度顺序为 (lat, lon)
vari_mean = vari_mean.transpose('lat', 'lon')
# 赋予坐标信息（确保 nc 文件具有 lat/lon
vari_mean = vari_mean.rio.set_spatial_dims(x_dim="lon", y_dim="lat")
vari_mean = vari_mean.rio.write_crs("EPSG:4326")
if gdf.crs != vari_mean.rio.crs:
    gdf = gdf.to_crs(vari_mean.rio.crs)
plt.imshow(vari_mean)
plt.show()
# 或者保存为 GeoTIFF
vari_mean.rio.to_raster(f"F:/phd1/V6/01allsite/08RF/rasterdata/temp/{vari}.tif")
#逐站点提取
tif_ext = zonal_stats(
    gdf,
    vari_mean.values,
    affine=vari_mean.rio.transform(),
    stats="mean",  # 可以指定多个统计量，例如 "min", "max", "median", "mean" 等
    geojson_out=True,  # 如果需要保留与矢量面对应的信息
    multiprocessing=True,
    all_touched=True
)
# 从 stats 提取 siteid 和 mean 值
feature_data = [{"siteid": feature["properties"]["siteid"], "mean_value": feature["properties"]["mean"]} for feature in tif_ext]
# 构建 DataFrame
tif_ext1 = pd.DataFrame(feature_data)
tif_ext1.to_csv('F:/phd1/V6/01allsite/08RF/varix/'+vari+'.csv', index=True, header=True, float_format='%.4f')

#%%提取gcmax
vari = 'gpmax'
shp_file = "F:/phd1/V6/01allsite/08RF/sitefilter/filter_buffer.shp"
gdf = gpd.read_file(shp_file, encoding='utf-8')    
pft_tif = xr.open_dataset('F:/phd1/V6/01allsite/08RF/rasterdata/PFT/'+vari+'.nc')  #读取tif数据
vari_list = list(pft_tif.variables)   #获取变量
shape_size = pft_tif['gpmax_50'].shape  #获取尺寸
lat_list = pft_tif.lat.values
backvalue = pft_tif['gpmax_50'].isel(lat=0, lon=0).values
pft_tif.where(pft_tif != backvalue, np.nan)  # 将背景值替换为NaN
vari_nc = pft_tif['gpmax_50']
#上下翻转
if vari_nc.lat[0] < vari_nc.lat[-1]:
    vari_nc = vari_nc.sel(lat=slice(None, None, -1))
# 赋予坐标信息（确保 nc 文件具有 lat/lon
vari_nc = vari_nc.rio.set_spatial_dims(x_dim="lon", y_dim="lat")
vari_nc = vari_nc.rio.write_crs("EPSG:4326")
if gdf.crs != vari_nc.rio.crs:
    gdf = gdf.to_crs(vari_nc.rio.crs)
plt.imshow(vari_nc)
plt.show()
#逐站点提取
tif_ext = zonal_stats(
    gdf,
    vari_nc.values,
    affine=vari_nc.rio.transform(),
    stats="mean",  # 可以指定多个统计量，例如 "min", "max", "median", "mean" 等
    geojson_out=True,  # 如果需要保留与矢量面对应的信息
    multiprocessing=True,
    all_touched=True
)
# 从 stats 提取 siteid 和 mean 值
feature_data = [{"siteid": feature["properties"]["siteid"], "mean_value": feature["properties"]["mean"]} for feature in tif_ext]
# 构建 DataFrame
tif_ext1 = pd.DataFrame(feature_data)
tif_ext1.to_csv('F:/phd1/V6/01allsite/08RF/varix/'+vari+'.csv', index=True, header=True, float_format='%.4f')

#%%

