# -*- coding: utf-8 -*-
"""
Created on Mon Oct 14 21:23:55 2024

@author: LF
"""
'''本程序用于提取有关干旱指数AI、地表径流和地下水深的统计量'''
import os
import re
import gc 
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import rioxarray as rxr
import geopandas as gpd
from rasterstats import zonal_stats
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%提取干旱指数AI
#@njit(parallel=True)  # 开启并行
shp_file = "/public/data/lifeng/phd1/rasterdata/filter_buffer.shp"
gdf = gpd.read_file(shp_file, encoding='utf-8')
#gdf = gdf.to_crs("EPSG:4326")
ai_tif = rxr.open_rasterio('/public/data/lifeng/phd1/rasterdata/mete/ai_v3_yr.tif', chunks=True).squeeze()  #读取tif数据
# 进行重投影到 EPSG:4326
if gdf.crs != ai_tif.rio.crs:
    #ai_tif = ai_tif.rio.write_crs("EPSG:4326")
    gdf = gdf.to_crs(ai_tif.rio.crs)
ai_tif1 = ai_tif/10000.0
ai_tif2 = ai_tif1.where(ai_tif1 >= 0, np.nan) #AI越大越湿润。
plt.imshow(ai_tif2)
plt.show()
# 将 DataArray 保存为临时 tif 文件
ai_temp = "/public/data/lifeng/phd1/rasterdata/temp/ai.tif"
ai_tif2.rio.to_raster(ai_temp)
#%%方法一
# 提取每个多边形的平均值
ai_ext = pd.DataFrame(index = range(len(gdf)),columns=['siteid','ai'])
for index, row in gdf.iterrows():
    geometry = row['geometry']  # 获取当前多边形的几何信息
    clipped = ai_tif2.rio.clip([geometry], crs = gdf.crs, all_touched=True,from_disk=True)  # 裁剪TIFF数据到当前多边形范围
    mean_value = np.nanmean(clipped.values)  # 计算平均值，忽略NaN值
    ai_ext.loc[index,'ai'] = mean_value  # 存储结果
    ai_ext.loc[index,'siteid'] = row['siteid']
    if 'clipped' in locals():
        del clipped
    # 手动触发垃圾回收（放在循环内部每次迭代结束）
    gc.collect()
    print(row['siteid'])
ai_ext.to_excel("/public/data/lifeng/phd1/varix/mete/ai.xlsx", index=True,header=True)

#%% 方法二
ai_ext = zonal_stats(
    gdf,
    ai_temp,
    stats="mean",  # 可以指定多个统计量，例如 "min", "max", "median", "mean" 等
    geojson_out=True,  # 如果需要保留与矢量面对应的信息
    multiprocessing=True,
    all_touched=True
)
# 从 stats 提取 siteid 和 mean 值
feature_data = [{"siteid": feature["properties"]["siteid"], "mean_value": feature["properties"]["mean"]} for feature in ai_ext]
# 构建 DataFrame
ai_ext1 = pd.DataFrame(feature_data)
# 保存为 CSV 文件
ai_ext1.to_excel("/public/data/lifeng/phd1/varix/mete/ai.xlsx", index=False)
#%%提取地表径流
shp_file = "/public/data/lifeng/phd1/rasterdata/filter_buffer.shp"
gdf = gpd.read_file(shp_file, encoding='utf-8')
runoff_tif = rxr.open_rasterio('/public/data/lifeng/phd1/rasterdata/hydro/runoff.tif', chunks=True, nodata=-9999).squeeze()
# 进行重投影到 EPSG:4326
if gdf.crs != runoff_tif.rio.crs:
    gdf = gdf.to_crs(runoff_tif.rio.crs)
plt.imshow(runoff_tif)
plt.show()
# 将 DataArray 保存为临时 tif 文件
runoff_path = "/public/data/lifeng/phd1/rasterdata/temp/runoff.tif"
runoff_tif.rio.to_raster(runoff_path)
runoff_ext = zonal_stats(
    gdf,
    runoff_path,
    stats="mean",  # 可以指定多个统计量，例如 "min", "max", "median", "mean" 等
    geojson_out=True,  # 如果需要保留与矢量面对应的信息
    multiprocessing=True,
    all_touched=True
)
# 从 stats 提取 siteid 和 mean 值
feature_data = [{"siteid": feature["properties"]["siteid"], "mean_value": feature["properties"]["mean"]} for feature in runoff_ext]
# 构建 DataFrame
runoff_ext1 = pd.DataFrame(feature_data)
runoff_ext1.to_excel('/public/data/lifeng/phd1/varix/hydro/runoff.xlsx', index=True, header=True, float_format='%.4f')
#%%提取地下水深
shp_file = "/public/data/lifeng/phd1/rasterdata/filter_buffer.shp"
gdf = gpd.read_file(shp_file, encoding='utf-8')
gtd_tif = rxr.open_rasterio('/public/data/lifeng/phd1/rasterdata/hydro/groundwater.tif', chunks=True, nodata=-9999).squeeze()
#gtd_tif = gtd_tif.where(gtd_tif < 0, np.nan)
if gdf.crs != gtd_tif.rio.crs:
    gdf = gdf.to_crs(gtd_tif.rio.crs)
plt.imshow(gtd_tif)
plt.show()
# 将 DataArray 保存为临时 tif 文件
gtd_path = "/public/data/lifeng/phd1/rasterdata/temp/groundwater.tif"
gtd_tif.rio.to_raster(gtd_path)
gtd_ext = zonal_stats(
    gdf,
    gtd_tif.values,
    affine=gtd_tif.rio.transform(),
    stats="mean",  # 可以指定多个统计量，例如 "min", "max", "median", "mean" 等
    geojson_out=True,  # 如果需要保留与矢量面对应的信息
    multiprocessing=True,
    all_touched=True
)
# 从 stats 提取 siteid 和 mean 值
feature_data = [{"siteid": feature["properties"]["siteid"], "mean_value": feature["properties"]["mean"]} for feature in gtd_ext]
# 构建 DataFrame
gtd_ext1 = pd.DataFrame(feature_data)
gtd_ext1.to_excel('/public/data/lifeng/phd1/varix/hydro/groundwater.xlsx', index=True, header=True, float_format='%.4f')




