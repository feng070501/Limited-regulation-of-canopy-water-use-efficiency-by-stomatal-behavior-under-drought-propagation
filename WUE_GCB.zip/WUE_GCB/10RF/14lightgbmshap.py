# -*- coding: utf-8 -*-
"""
Created on Fri Oct 18 22:01:24 2024

@author: LF
"""
'''本程序用于lightgbm和SHAP'''
#######第18行替换变量
import pandas as pd
import lightgbm as lgb
from sklearn.feature_selection import RFE
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.model_selection import train_test_split
import optuna
from optuna.integration import LightGBMPruningCallback
import matplotlib.pyplot as plt
import shap
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
# 读取数据
vari = 'Gc'
df = pd.read_csv('F:/phd1/V10/01allsite/08RF/factors/factors_6.csv', index_col=0, header=0)
y = df[vari]
X = df.drop(columns=['ET','GPP', 'Gc', 'T', 'EWUE', 'TWUE', 'IWUE'])
# 变量筛选（使用 RFECV）
model_ini = lgb.LGBMRegressor(random_state=14, n_jobs=8)
selector = RFE(estimator = model_ini, step=3, n_features_to_select=10, verbose=1)
selector.fit(X, y)
selected_features = X.columns[selector.support_]  
X_selected = X[selected_features]
# 拆分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X_selected, y, random_state=14)
# 超参数优化
def objective(trial):
    params = {
        'n_estimators': trial.suggest_categorical('n_estimators', [50, 100, 300, 500, 1000]),
        'num_leaves': trial.suggest_int('num_leaves', 10, 100, step=10),
        'learning_rate': trial.suggest_loguniform('learning_rate', 0.01, 0.3),
        "max_depth": trial.suggest_int("max_depth", 3, 12),
        'colsample_bytree': trial.suggest_uniform('colsample_bytree', 0.5, 1.0),
        'subsample': trial.suggest_uniform('subsample', 0.5, 1.0),
        'min_data_in_leaf': trial.suggest_int('min_data_in_leaf', 5, 50, step=5),
        "lambda_l1": trial.suggest_int("lambda_l1", 0, 100, step=5),
        "lambda_l2": trial.suggest_int("lambda_l2", 0, 100, step=5),
        "min_gain_to_split": trial.suggest_float("min_gain_to_split", 0, 15, step=0.1),
        "bagging_fraction": trial.suggest_float("bagging_fraction", 0.2, 0.95, step=0.1),
        "bagging_freq": trial.suggest_categorical("bagging_freq", [1]),
    }
    
    model_trial = lgb.LGBMRegressor(**params, random_state=14, n_jobs=8)
    callback = [lgb.early_stopping(stopping_rounds=50,verbose=False),
          lgb.log_evaluation(period=10,show_stdv=True)]
    model_trial.fit(X_train, y_train, eval_set=[(X_test, y_test)], eval_metric="rmse", callbacks=callback)    
    y_pred = model_trial.predict(X_test)
    loss = mean_squared_error(y_test, y_pred)
    return loss
#study = optuna.create_study(direction="minimize", sampler=optuna.samplers.TPESampler(seed=14))
study = optuna.create_study(direction="minimize")
study.optimize(objective, n_trials=1)
print("Best parameters:", study.best_params)
# 训练最优模型
best_model = lgb.LGBMRegressor(**study.best_params, random_state=14, n_jobs=8)
best_model.fit(X_selected, y)
# 模型预测
y_pred1 = best_model.predict(X_selected)
r2 = r2_score(y, y_pred1)
rmse = mean_squared_error(y, y_pred1)
#计算SHAP值
explainer = shap.Explainer(best_model)
shap_values = explainer(X_selected)    
# 输出 SHAP 值
shap_df = pd.DataFrame(shap_values.values, columns=X_selected.columns)        
mean_shap_values = shap_df.abs().mean().reset_index() # 计算每个变量的 SHAP 值的平均绝对值
mean_shap_np = shap_df.mean().reset_index() # 计算每个变量的 SHAP 值的平均绝对值
mean_shap_values.columns = ['Variable', 'Mean_SHAP_Value']
mean_shap_np.columns = ['Variable', 'Mean_SHAP_np']
shap_mean = pd.merge(mean_shap_values, mean_shap_np, on='Variable')
shap_mean1 = shap_mean.sort_values(by='Mean_SHAP_Value', ascending=False)    
shap_mean1.to_excel('F:/phd1/V10/01allsite/08RF/LightGBM/'+vari+'_lgb6.xlsx', index=False) # 输出为 Excel 表格
#%%绘制特征重要性
fig = plt.figure(figsize=(10, 6))  # 设置图像尺寸
plt.rcParams['font.family'] = 'Arial'  # 可以替换为你想要的字体
plt.rcParams['font.size'] = 45  # 设置字体大小
shap_plot = shap.summary_plot(shap_values, X_selected, max_display=10, plot_type="layered_violin", color="coolwarm", show=False)
plt.title(vari, fontsize=20)
plt.xlabel('SHAP value')
plt.text(0.2, 0.25, f"R² = {r2:.2f}", verticalalignment='top', fontsize=14, transform=fig.transFigure)
plt.xlim(-6, 6)  # 根据需要设置范围
plt.gcf().set_dpi(300)
plt.savefig('F:/phd1/V10/01allsite/08RF/LightGBM/'+vari+'_lgb6.jpg', dpi=300)
plt.show()
