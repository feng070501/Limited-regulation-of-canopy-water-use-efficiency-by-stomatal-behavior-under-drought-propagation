# -*- coding: utf-8 -*-
"""
Created on Thu Oct 17 09:28:13 2024

@author: LF
"""
'''本程序用于从mat数据中提取站点信息。'''
import os
import glob
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import rioxarray as rxr
import xarray as xr
from scipy.io import loadmat
import geopandas as gpd
from rasterstats import zonal_stats
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
vari='PHR'
# 1. 读取Excel文件中的站点经纬度
shp_file = "F:/phd1/V6/01allsite/08RF/sitefilter/filter_buffer.shp"
gdf = gpd.read_file(shp_file, encoding='utf-8') 
# 2. 加载MAT文件并提取数据
mat_file = 'F:/phd1/V6/01allsite/08RF/rasterdata/PFT/'+vari+'.mat'
mat_data = loadmat(mat_file)
for var in mat_data:  #获取变量名    
    print(var)
#%%
data_grid = mat_data['Rplant_proxy'][0,0]  # 提取数据矩阵
for field in data_grid.dtype.names:
    print(field) # 查看该元素的字段
mat_arr = mat_data['Rplant_proxy'][0,0]['Rplant_proxy']
lon_list = data_grid['longitude'][0,:]
lat_list = data_grid['latitude'][:,0]

mat_frame = pd.DataFrame(mat_arr, index=lat_list, columns=lon_list)
plt.imshow(mat_frame, cmap='viridis', interpolation='nearest')
plt.show()
# 将 DataFrame 转换为 xarray DataArray
data_array = xr.DataArray(mat_frame.values, coords=[("lat", lat_list), ("lon", lon_list)])
# 设置地理坐标
data_array = data_array.rio.set_spatial_dims(x_dim="lon", y_dim="lat")
data_array.rio.write_crs("EPSG:4326", inplace=True)
# 保存为 GeoTIFF
outif = 'F:/phd1/V6/01allsite/08RF/rasterdata/temp/'+vari+'.tif'
data_array.rio.to_raster(outif)
#%%
tif_ext = zonal_stats(
    gdf,
    data_array.values,
    affine=data_array.rio.transform(),
    stats="mean",  
    geojson_out=True,  # 如果需要保留与矢量面对应的信息
    multiprocessing=True,
    all_touched=True
)
# 从 stats 提取 siteid 和 mean 值
feature_data = [{"siteid": feature["properties"]["siteid"], "mean_value": feature["properties"]["mean"]} for feature in tif_ext]
# 构建 DataFrame
tif_ext1 = pd.DataFrame(feature_data)
tif_ext1.to_csv('F:/phd1/V6/01allsite/08RF/varix/'+vari+'.csv', index=True, header=True, float_format='%.4f')



