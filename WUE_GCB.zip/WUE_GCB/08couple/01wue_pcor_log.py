# -*- coding: utf-8 -*-
"""
Created on Wed Apr 24 10:23:49 2024

@author: LF
"""
'''本程序用于对分组数据计算偏相关系数。'''
#注意更换IGBP,所有站点与不分igbp
import os
import re
import glob 
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import pingouin as pg
import scipy.stats as stats
from scipy.stats import kstest
from scipy.stats import yeojohnson
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%bootstraping采样后进行偏相关
def mypcor(grouped_df, vari1, vari2, vari3, igbp):
    #grouped_df为分好组的数据，vari1是X变量, vari2是y变量, vari3是控制变量。
    pcor_df = pd.DataFrame(columns = ['1', '2', '3', '4', '5', '6', '7', '8'])
    for group_name, group_data in grouped_df: # 遍历每个组并输出对应的偏相关
        group_data = group_data.drop('DI', axis=1)  #删除第1列
        pcor_list = pd.Series(index=list(range(0,1000)))    
        for ii in range(1000):
            group_sample = group_data.sample(frac=0.7, replace=True)
            pcor = pg.partial_corr(data=group_sample, x=vari1, y=vari2, covar=vari3, method='spearman')['r'][0]
            pcorp = pg.partial_corr(data=group_sample, x=vari1, y=vari2, covar=vari3, method='spearman')['p-val'][0]
            if pcorp<0.05:
                pcor_list[ii]=pcor        
        pcor_df[str(int(group_name))] = pcor_list    
        print(len(group_sample))
    pcor_df.to_csv('F:/phd1/V10/01allsite/06couple/'+vari1+'-'+vari2+'_log.csv', index=True, header=True, float_format='%.4f')
    return pcor_df
#%%
dir_list = glob.glob(r'F:/phd1/V10/*/*/03data_flt/data_zscflt.csv')
dfs = []
for dd in dir_list:
    dd = dd.replace('\\', '/')
    substrings = re.split(r'/', dd)  # 按/分割
    igbp = substrings[3]
    siteid = substrings[4]        
    
    ori_frame = pd.read_csv(dd, index_col=0, parse_dates=True, header=0)
    et_frame = ori_frame['et']
    t_frame = ori_frame['t']
    gpp_frame = ori_frame['gpp']
    csvpath1 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/06WUE/gc_zscflt.csv'
    gc_frame = pd.read_csv(csvpath1, index_col=0, parse_dates=True, header=0)
    csvpath2 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/06WUE/ewue_zscflt.csv'
    ewue_frame = pd.read_csv(csvpath2, index_col=0, parse_dates=True, header=0)
    csvpath3 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/06WUE/twue_zscflt.csv'
    twue_frame = pd.read_csv(csvpath3, index_col=0, parse_dates=True, header=0)
    csvpath4 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/06WUE/iwue_zscflt.csv'
    iwue_frame = pd.read_csv(csvpath4, index_col=0, parse_dates=True, header=0)
    csvpath5 = 'F:/phd1/V10/'+igbp+'/'+siteid+'/05SMDI/spei_smdi.csv'
    spei_smdi = pd.read_csv(csvpath5, index_col=0, parse_dates=True, header=0)
    di_frame = pd.DataFrame(spei_smdi["DI"])
    common_df1 = pd.merge(di_frame, et_frame, how='inner', left_index=True, right_index=True) #取交集合并各dataframe
    common_df2 = pd.merge(common_df1, t_frame, how='inner', left_index=True, right_index=True)
    common_df3 = pd.merge(common_df2, gpp_frame, how='inner', left_index=True, right_index=True)
    common_df4 = pd.merge(common_df3, gc_frame, how='inner', left_index=True, right_index=True)
    common_df5 = pd.merge(common_df4, ewue_frame, how='inner', left_index=True, right_index=True)
    common_df6 = pd.merge(common_df5, twue_frame, how='inner', left_index=True, right_index=True)
    common_df = pd.merge(common_df6, iwue_frame, how='inner', left_index=True, right_index=True)    
    common_df.dropna(inplace=True) #删除nan位置所在的元素
    dfs.append(common_df)
combined_df = pd.concat(dfs, axis=0) # 使用pd.concat函数进行上下合并
combined_df.reset_index(drop=True, inplace=True)   # 重置索引（可选），以使合并后的DataFrame有连续的索引
# 创建一个新的 DataFrame 来存储变换后的数据
combined_log = combined_df.copy()
col_list = combined_df.columns.to_list()[1:8]
# 对每一列进行 Yeo-Johnson 变换
for cc in col_list:
    combined_log[cc], _ = yeojohnson(combined_df[cc])
    # 执行 Kolmogorov-Smirnov 检验
    res = kstest(combined_log[cc], 'norm', args=(combined_log[cc].mean(), combined_log[cc].std()))   
    # 输出检验结果
    print(f"Statistic: {res.statistic}")
    print(f"P-value: {res.pvalue}")
    # # 绘制 Q-Q 图
    # plt.subplot(1, 2, 2)
    # stats.probplot(combined_log[cc], dist="norm", plot=plt)
    # plt.title(f'{cc} - Q-Q plot')
    # plt.tight_layout()
    # plt.show()
#%%       
grouped = combined_log.groupby('DI') # 使用groupby函数按第一列分组
ewue_gpp = mypcor(grouped, 'gpp', 'EWUE', 'et', igbp)
ewue_et = mypcor(grouped, 'et', 'EWUE', 'gpp', igbp)
twue_gpp = mypcor(grouped, 'gpp', 'TWUE', 't', igbp)
twue_t = mypcor(grouped, 't', 'TWUE', 'gpp', igbp)
iwue_gpp = mypcor(grouped, 'gpp', 'IWUE', 'gc', igbp)
iwue_gc = mypcor(grouped, 'gc', 'IWUE', 'gpp', igbp)
