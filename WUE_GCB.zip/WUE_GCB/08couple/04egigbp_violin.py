# -*- coding: utf-8 -*-
"""
Created on Wed Sep 25 16:02:35 2024

@author: LF
"""
'''根据分组的各相关系数绘制小提琴图。'''
############分igbp站点多处需手动修改
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%
def data_violin(path):   #准备小提琴图数据   
    pcor = pd.read_csv(path, index_col=0, parse_dates=True, header=0).abs()
    group_unique_values = [int(item) for item in list(pcor.columns)]  # 确保按顺序取出唯一组别
    tab10 = plt.get_cmap('tab10')# 获取tab10调色板
    value_to_color_index = {
        1: 0,  # tab10的第0个颜色 (索引从0开始，所以2是第3个)
        2: 4,  # tab10的第4个颜色
        3: 2,  # tab10的第2个颜色
        4: 1,  # tab10的第1个颜色
        5: 3,  # tab10的第3个颜色
        6: 5,  # tab10的第5个颜色
        7: 8,  # tab10的第8个颜色
        8: 6,  # tab10的第6个颜色    
    }
    colors = [tab10(value_to_color_index[val]) for val in group_unique_values]
    melted_couple = pcor.melt(var_name='group', value_name='pcor', ignore_index = True) #短数据变长数据
    couple2 = melted_couple.dropna(subset=['pcor']).reset_index(drop=True) #删除nan值
    return couple2, colors
#%%
csvpath1 = 'F:/phd1/V10/SHR/01multisite/03couple/et-gpp.csv'
csvpath2 = 'F:/phd1/V10/SHR/01multisite/03couple/t-gpp.csv'
csvpath3 = 'F:/phd1/V10/SHR/01multisite/03couple/gc-gpp.csv'
csvpath4 = 'F:/phd1/V10/SHR/01multisite/03couple/gc-t.csv'
gpp_et, color1 = data_violin(csvpath1)
gpp_t, color2 = data_violin(csvpath2)
gc_gpp, color3 = data_violin(csvpath3)
gc_t, color4 = data_violin(csvpath4)

parameters = {'axes.labelsize': 35,
          'axes.titlesize': 35,
          'xtick.labelsize': 30,
          'ytick.labelsize': 30,
          'figure.dpi': 300,
          'lines.linewidth': 3,
          'font.family': 'Arial',
          'axes.titlepad': 20}
plt.rcParams.update(parameters)
new_labels = ['P1', 'P2', 'P3', 'P4', 'P5', 'P6', 'P7', 'P8']  # 自定义刻度标签
fig, axes = plt.subplots(2, 2, figsize=(15, 10))

sns.violinplot(x='group', y='pcor', data=gpp_et, ax=axes[0,0], palette=color1)  # 在指定的axes对象ax上绘制小提琴图
axes[0,0].set_ylim(0, 1)
axes[0,0].set_title('|pcor(GPP, ET)|')
axes[0,0].set_xlabel('', fontsize=30)
axes[0,0].set_ylabel('', fontsize=40, labelpad = 20)
axes[0,0].set_xticklabels([])# 设置新的刻度标签
axes[0,0].yaxis.set_major_locator(ticker.MultipleLocator(0.2))  #显示1位刻度标签
sns.violinplot(x='group', y='pcor', data=gpp_t, ax=axes[0,1], palette=color2)  # 在指定的axes对象ax上绘制小提琴图
axes[0,1].set_ylim(0.0, 1)
axes[0,1].set_title('|pcor(GPP, T)|')
axes[0,1].set_xlabel('', fontsize=30)
axes[0,1].set_ylabel('')
axes[0,1].set_xticklabels([])
axes[0,1].set_yticklabels([])
axes[0,1].yaxis.set_major_locator(ticker.MultipleLocator(0.2))  #显示1位刻度标签
sns.violinplot(x='group', y='pcor', data=gc_gpp, ax=axes[1,0], palette=color3)  # 在指定的axes对象ax上绘制小提琴图
axes[1,0].set_ylim(0, 1)
axes[1,0].set_title('|pcor(GPP, Gc)|')
axes[1,0].set_xlabel('Drought Phases', fontsize=30)
axes[1,0].set_ylabel('', fontsize=40, labelpad = 20)
axes[1,0].set_xticklabels(new_labels)# 设置新的刻度标签
axes[1,0].yaxis.set_major_locator(ticker.MultipleLocator(0.2))  #显示1位刻度标签
sns.violinplot(x='group', y='pcor', data=gc_t, ax=axes[1,1], palette=color4)  # 在指定的axes对象ax上绘制小提琴图
axes[1,1].set_ylim(0.0, 1)
axes[1,1].set_title('|pcor(T, Gc)|')
axes[1,1].set_xlabel('Drought Phases', fontsize=30)
axes[1,1].set_ylabel('')
axes[1,1].set_xticklabels(new_labels)
axes[1,1].set_yticklabels([])
axes[1,1].yaxis.set_major_locator(ticker.MultipleLocator(0.2))  #显示1位刻度标签

plt.tight_layout()
plt.show()
fig.savefig('F:/phd1/V10/SHR/01multisite/03couple/SHR_eg_violin.jpg',dpi=300, format='jpg', bbox_inches='tight')
