# -*- coding: utf-8 -*-
"""
Created on Mon Oct 21 20:11:43 2024

@author: LF
"""
'''本程序用于进行各组之间的Kruskal-Wallis检验。'''
#注意更改IGBP
import glob
import os
import pandas as pd
import numpy as np
import re
from scipy.stats import kruskal
from scikit_posthocs import posthoc_dunn
import warnings
warnings.filterwarnings('ignore')# 屏蔽所有警告信息
#%%

def dunn_p(csvpath1, csvpath2, varname):
    file_name = os.path.splitext(os.path.basename(csvpath1))[0]
    var2 = re.split(r'-', file_name)[1]
    pcor1 = pd.read_csv(csvpath1, index_col=0, header=0).abs()
    pcor2 = pd.read_csv(csvpath2, index_col=0, header=0).abs()
    p_values = pd.DataFrame(columns=['Column', 'Kruskal-Wallis p-value', 'Dunn\'s test p-values'])
    for col in pcor1.columns:
        # 提取df1和df2中对应列的数据
        data1 = pcor1[col].dropna()
        data2 = pcor2[col].dropna()    
        # Kruskal-Wallis检验
        stat, p_kw = kruskal(data1, data2)    
        # Dunn's检验
        data = [data1, data2]
        p_dunn = posthoc_dunn(data, p_adjust='bonferroni')    
        # 存储p值
        new_row = pd.DataFrame([{
        'Column': col,
        'Kruskal-Wallis p-value': p_kw,
        'Dunn\'s test p-values': p_dunn.iloc[0, 1]
        }])
        p_values = pd.concat([p_values, new_row], ignore_index=True)
    p_values.to_excel(f'F:/phd1/V10/01allsite/06couple/{varname}_dunn.xlsx', index=False)
    return p_values
csvpath1 = 'F:/phd1/V10/01allsite/06couple/gpp-EWUE.csv'
csvpath2 = 'F:/phd1/V10/01allsite/06couple/et-EWUE.csv'
csvpath1 = 'F:/phd1/V10/01allsite/06couple/gpp-EWUE.csv'
csvpath2 = 'F:/phd1/V10/01allsite/06couple/et-EWUE.csv'
csvpath3 = 'F:/phd1/V10/01allsite/06couple/gpp-TWUE.csv'
csvpath4 = 'F:/phd1/V10/01allsite/06couple/t-TWUE.csv'
csvpath5 = 'F:/phd1/V10/01allsite/06couple/gpp-IWUE.csv'
csvpath6 = 'F:/phd1/V10/01allsite/06couple/gc-IWUE.csv'
csvpath7 = 'F:/phd1/V10/01allsite/06couple/gc-gpp.csv'
csvpath8 = 'F:/phd1/V10/01allsite/06couple/gc-t.csv'
csvpath9 = 'F:/phd1/V10/01allsite/06couple/t-gpp.csv'
csvpath10 = 'F:/phd1/V10/01allsite/06couple/et-gpp.csv'
ewue = dunn_p(csvpath1, csvpath2, 'EWUE')
twue = dunn_p(csvpath3, csvpath4, 'TWUE')
iwue = dunn_p(csvpath5, csvpath6, 'IWUE')
tg = dunn_p(csvpath7, csvpath8, 'Gc')
eg = dunn_p(csvpath9, csvpath10, 'GPP')

